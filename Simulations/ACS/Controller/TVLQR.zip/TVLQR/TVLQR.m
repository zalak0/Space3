clc
clear all;

%% ── Physical constants and inertia ───────────────────────────────────
mu        = 3.986e14;
earth_rad = 6371000;
r         = earth_rad + 515000;
period    = (2*pi * r^(3/2)) / sqrt(mu);
omega     = (2*pi) / period;

mass = 2.0;  Lx = 0.226;  Ly = 0.100;  Lz = 0.100;
Ix = (1/12)*mass*(Ly^2+Lz^2);
Iy = (1/12)*mass*(Lx^2+Lz^2);
Iz = (1/12)*mass*(Lx^2+Ly^2);

A = [ 0,  1,  0,  0,  0,  0;
     -4*omega^2*(Iy-Iz)/Ix,  0,  0,  0,  0,  omega*(Ix+Iz-Iy)/Ix;
      0,  0,  0,  1,  0,  0;
      0,  0, -3*omega^2*(Ix-Iz)/Iy,  0,  0,  0;
      0,  0,  0,  0,  0,  1;
      0, -omega*(Iz+Ix-Iy)/Iz,  0,  0, -omega^2*(Iy-Ix)/Iz,  0];

B = [0,    0,    0;
     1/Ix, 0,    0;
     0,    0,    0;
     0,    1/Iy, 0;     % theta_ddot from u(2)
     0,    0,    0;
     0,    0,    1/Iz]; % psi_ddot from u(3)

C = eye(6);  D = zeros(6,3);

%% ── Discretise ───────────────────────────────────────────────────────
dt_ctrl = 0.1;   % control timestep [s] — never overwrite this
sys_c   = ss(A, B, C, D);
sys_d   = c2d(sys_c, dt_ctrl, 'zoh');
Ad = sys_d.A;  Bd = sys_d.B;  Cd = sys_d.C;  Dd = sys_d.D;

%% ── Cost weights — define ONCE, use everywhere ────────────────────────
phi_max   = 5  * pi/180;
rate_max  = 0.5 * pi/180;
m_max_pss = 0.166;   % A·m² — dipole hardware limit

Q = diag([1/phi_max^2,  1/rate_max^2, ...
          1/phi_max^2,  1/rate_max^2, ...
          1/phi_max^2,  1/rate_max^2]);

R_pss     = diag([1/m_max_pss^2, 1/m_max_pss^2, 1/m_max_pss^2]);
R_inv_pss = diag([m_max_pss^2,   m_max_pss^2,   m_max_pss^2]);

%% ── Warm-start P0 from standard LQR ──────────────────────────────────
% Use torque-space B for warm-start only
[K_lqr, P0, ~] = lqr(A, B, Q, R_pss);

fprintf('P0 diagonal:\n');  disp(diag(P0)')

%% ── Load disturbances ────────────────────────────────────────────────
mag  = load('GOOSE_mag_Td.mat');
aero = load('GOOSE_aero_Td.mat');
srp  = load('GOOSE_srp_Td.mat');

[T_disturbance, Td_reordered, idx] = ext_disturbances(mag, aero, srp, K_lqr);

%% ── Magnetic field: ECI → LVLH ───────────────────────────────────────
t_tv      = mag.t;
B_eci     = mag.B_eci;
r_eci_arr = srp.r_eci_m;
v_eci_arr = srp.v_eci_m;
N_tv      = length(t_tv);

B_lvlh = zeros(N_tv, 3);
for i = 1:N_tv
    B_lvlh(i,:) = eci_to_lvlh(B_eci(i,:), r_eci_arr(i,:), v_eci_arr(i,:));
end

%% ── Trim and repeat for Simulink ─────────────────────────────────────
t_tv_trimmed   = t_tv(idx);
B_lvlh_trimmed = B_lvlh(idx,:);
Td_trimmed     = Td_reordered(idx,:);

N_repeat  = 10;
dt_data   = t_tv(2) - t_tv(1);        % 10s — data resolution
T_total   = length(t_tv_trimmed) * dt_data;

B_lvlh_rep = repmat(B_lvlh_trimmed, N_repeat, 1);
Td_rep     = repmat(Td_trimmed,     N_repeat, 1);

t_offsets = (0:N_repeat-1)' * T_total;
t_rep     = repmat(t_tv_trimmed, N_repeat, 1) + ...
            repelem(t_offsets, length(t_tv_trimmed));

B_lvlh_ts = timeseries(B_lvlh_rep, t_rep);
Td_ts     = timeseries(Td_rep,     t_rep);

%% ── Constant-B Pss (sanity check mode) ───────────────────────────────
%% ── Time-averaged Pss via averaged ARE ───────────────────────────────
% Step 1: Build B_tv(t) over one orbital period using your real B_lvlh data
%         But B_tv needs B_body, not B_lvlh — and B_body depends on attitude,
%         which we don't have yet. So we make the linearisation assumption:
%         around nominal pointing, B_body ≈ B_lvlh (since attitude error is small).
%         This is exactly what Psiaki does.

N_orbit = length(t_tv_trimmed);   % samples in one orbit
G_sum = zeros(6,6);

for k = 1:N_orbit
    Bx = B_lvlh_trimmed(k,1);
    By = B_lvlh_trimmed(k,2);
    Bz = B_lvlh_trimmed(k,3);
    
    B_cross_k = [  0,   Bz, -By;
                  -Bz,   0,  Bx;
                   By, -Bx,   0];
    
    B_tv_k = zeros(6,3);
    B_tv_k(2,:) = B_cross_k(1,:) / Ix;
    B_tv_k(4,:) = B_cross_k(2,:) / Iy;
    B_tv_k(6,:) = B_cross_k(3,:) / Iz;
    
    G_sum = G_sum + B_tv_k * R_inv_pss * B_tv_k';
end

G_avg = G_sum / N_orbit;   % time-averaged B*R^-1*B'

[V, D] = eig(G_avg);
d = diag(D);
% Clip tiny/negative eigenvalues from numerical noise
d(d < max(d)*1e-10) = max(d)*1e-10;
L = V * diag(sqrt(d));   % G_avg ≈ L*L'
Pss = care(A, L, Q, eye(6));

fprintf('Time-averaged Pss:\n');
fprintf('  Positive definite: %d\n', all(eig(Pss) > 0));
fprintf('  Pss diagonal:\n');  disp(diag(Pss)')

fprintf('Constant-B Pss via lqr():\n');
fprintf('  Positive definite: %d\n', all(eig(Pss) > 0));
fprintf('  Pss diagonal:\n');  disp(diag(Pss)')
% 
% fprintf('G_avg'); disp(G_avg)
% fprintf('G_avg eigenvals'); disp(V); disp(D)

%% ── Gain check at 2° initial condition ──────────────────────────────
% Pick a representative B from the orbit (e.g., max-magnitude sample)
B_norms = vecnorm(B_lvlh_trimmed, 2, 2);
[~, k_max] = max(B_norms);
Bx = B_lvlh_trimmed(k_max,1);
By = B_lvlh_trimmed(k_max,2);
Bz = B_lvlh_trimmed(k_max,3);
B_cross_test = [0, Bz, -By; -Bz, 0, Bx; By, -Bx, 0];
B_tv_test = zeros(6,3);
B_tv_test(2,:) = B_cross_test(1,:) / Ix;
B_tv_test(4,:) = B_cross_test(2,:) / Iy;
B_tv_test(6,:) = B_cross_test(3,:) / Iz;

K_test = R_inv_pss * (B_tv_test' * Pss);
u_test = -K_test * [2*pi/180; 0; 2*pi/180; 0; 2*pi/180; 0];
fprintf('Max |u| at 2deg, max-B sample: %.4e A·m² (limit %.4e)\n', ...
    max(abs(u_test)), m_max_pss);
fprintf('Recommended alpha0: %.2f\n', 0.8*m_max_pss/max(abs(u_test)));

%% ── Floquet stability check ─────────────────────────────────────────
alpha0 = 1.34;   % start here, not 2.14
Phi = eye(6);
N_sub = 1000;    % sub-steps per 10s data interval
dt_sub = dt_data / N_sub;   % 0.1s

for k = 1:N_orbit
    Bx = B_lvlh_trimmed(k,1);
    By = B_lvlh_trimmed(k,2);
    Bz = B_lvlh_trimmed(k,3);
    B_cross_k = [0, Bz, -By; -Bz, 0, Bx; By, -Bx, 0];
    B_tv_k = zeros(6,3);
    B_tv_k(2,:) = B_cross_k(1,:) / Ix;
    B_tv_k(4,:) = B_cross_k(2,:) / Iy;
    B_tv_k(6,:) = B_cross_k(3,:) / Iz;

    K_k  = alpha0 * R_inv_pss * (B_tv_k' * Pss);
    A_cl = A - B_tv_k * K_k;

    % Sub-step integration — still ZOH within each 10s, but evaluated finely
    Phi_step = expm(A_cl * dt_sub);
    for s = 1:N_sub
        Phi = Phi_step * Phi;
    end
end

fprintf('Floquet multipliers (improved):\n');
disp(abs(eig(Phi)))
fprintf('Spectral radius: %.6f\n', max(abs(eig(Phi))));

% Add to setup script after Pss is computed
%% ── Standalone linear simulation of the closed loop ─────────────────
alpha0_sim = 1.34;
x = [2*pi/180; 0; 2*pi/180; 0; 2*pi/180; 0];   % 2deg IC
dt_sim = 0.1;
T_sim = 20 * 5695;   % 3 orbits
N_steps = round(T_sim / dt_sim);
x_hist = zeros(6, N_steps);
u_hist = zeros(3, N_steps);
t_hist = (0:N_steps-1) * dt_sim;

for k = 1:N_steps
    t = t_hist(k);
    % Interpolate B_lvlh
    t_mod = mod(t, T_total);
    B_now = interp1(t_tv_trimmed, B_lvlh_trimmed, t_mod, 'linear', 'extrap');
    
    % Build B_cross from B_lvlh (small-angle: body ≈ LVLH)
    Bx = B_now(1); By = B_now(2); Bz = B_now(3);
    B_cross_k = [0, Bz, -By; -Bz, 0, Bx; By, -Bx, 0];
    B_tv_k = zeros(6,3);
    B_tv_k(2,:) = B_cross_k(1,:) / Ix;
    B_tv_k(4,:) = B_cross_k(2,:) / Iy;
    B_tv_k(6,:) = B_cross_k(3,:) / Iz;
    
    % Control
    K_k = alpha0_sim * R_inv_pss * (B_tv_k' * Pss);
    u_nom = -K_k * x;
    beta = max(abs(u_nom) / m_max_pss);
    u_k = u_nom / max(beta, 1);
    
    % Plant: ẋ = Ax + B_tv*u
    xdot = A*x + B_tv_k * u_k;
    x = x + xdot * dt_sim;   % Euler integration
    
    x_hist(:,k) = x;
    u_hist(:,k) = u_k;
end

figure;
subplot(2,1,1);
plot(t_hist/5695, x_hist([1,3,5],:)' * 180/pi);
ylabel('angle [deg]'); legend('\phi','\theta','\psi'); grid on;
subplot(2,1,2);
plot(t_hist/5695, u_hist');
ylabel('u [A·m²]'); xlabel('orbits'); legend('m_x','m_y','m_z'); grid on;